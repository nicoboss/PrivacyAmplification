# Permission to Relicense under MPLv2

This is a statement by Thomas M. DuBuisson
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "tommd", with
commit author "Thomas M. DuBuisson", are copyright of Thomas M. DuBuisson.
This document hereby grants the libzmq project team to relicense libzmq,
including all past, present and future contributions of the author listed above.

Thomas M. DuBuisson
2019/04/11
