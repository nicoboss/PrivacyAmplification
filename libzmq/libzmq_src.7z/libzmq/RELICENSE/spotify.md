# Permission to Relicense under MPLv2

This is a statement by Spotify AB that grants permission to relicense its
copyrights in the libzmq C++ library (ZeroMQ) under the Mozilla Public License
v2 (MPLv2).

A portion of the commits made by the Github handle "gimaker", with commit author
"Staffan Gimåker", the commits made by the Github handle "danielnorberg", with
commit author "Daniel Norberg", and the commits made by the Github handle
"caipre", with commit author "Nick Platt", are copyright of Spotify AB. This
document hereby grants the libzmq project team to relicense libzmq, including
all past, present and future contributions of the authors listed above.

Nick Platt <nickplatt@spotify.com>
2019/08/21
